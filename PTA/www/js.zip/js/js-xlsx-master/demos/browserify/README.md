# Browserify

The library is compatible with browserify and should just work out of the box.

This demo uses the `require` form to expose the whole library, enabling client
code to just `require('xlsx')`.  The included demo and Makefile do just that.
