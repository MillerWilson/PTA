/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
var XLSX = require('../../'); // test against development version
//var XLSX = require('xlsx'); // use in production
module.exports = XLSX;
