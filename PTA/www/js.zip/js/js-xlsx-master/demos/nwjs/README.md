# NW.js

This library is compatible with NW.js and should just work out of the box.
The demonstration uses NW.js 0.24 with the dist script.

The standard HTML5 `FileReader` techniques from the browser apply to NW.js.
This demo includes a drag-and-drop box as well as a file input box, mirroring
the [SheetJS Data Preview Live Demo](http://oss.sheetjs.com/js-xlsx/)


