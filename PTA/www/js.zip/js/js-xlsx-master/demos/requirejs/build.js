/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
({
	baseUrl: ".",
	name: "requirejs",
	out: "requirejs-built.js"
})
